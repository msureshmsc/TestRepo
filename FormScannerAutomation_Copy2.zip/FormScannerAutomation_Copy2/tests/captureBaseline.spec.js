import { test, expect } from '@playwright/test';
import { DOMScanner } from '../utils/domScanner.js';
import * as XLSX from 'xlsx';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let config = {
  "testResultsFolder":"TestReports"
}

test.beforeAll(() => {
  // ✅ Timestamp generated *inside* the hook
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const baseDir = path.join(__dirname, '..', 'TestReports', `baseline_${timestamp}`);
  const pageSSDir = path.join(baseDir, 'screenshots', 'pages');
  const fieldSSDir = path.join(baseDir, 'screenshots', 'fields');
  const excelDir = path.join(baseDir, 'DomInExcel');

  // ✅ Only now create folders
  fs.mkdirSync(pageSSDir, { recursive: true });
  fs.mkdirSync(fieldSSDir, { recursive: true });
  fs.mkdirSync(excelDir, { recursive: true });

  // ✅ Write config file *after* directory creation
  const configPath = path.join(__dirname, '..', 'config.json');
  fs.writeFileSync(configPath, JSON.stringify({ baselineFolder: `baseline_${timestamp}` }, null, 2));

  config = {
    timestamp,
    baseDir,
    pageSSDir,
    fieldSSDir,
    excelDir
  };
});

test('Capture baseline screenshots and DOM info', async ({ page }) => {
  await page.goto('http://localhost:3000');

  // === 1. PAGE-LEVEL SCREENSHOT ===
  await page.screenshot({ path: path.join(config.pageSSDir, 'fullPage.png'), fullPage: true });

  // === 2. SCAN DOM ===
  const scanner = new DOMScanner(page);
  const elements = await scanner.scanVisibleActionableElements();

  const worksheetData = [['tag', 'text', 'id', 'name', 'type', 'forLabelValue', 'relativeXPath']];
  let fieldScreenshotCount = 0;

  for (const { tag, text, id, name, type, forLabelValue, relativeXPath } of elements) {
    worksheetData.push([tag, text, id, name, type, forLabelValue, relativeXPath]);

    try {
      const handle = await page.$(relativeXPath);
      if (handle) {
        const safeText = (text || '')
          .toLowerCase()
          .replace(/[^a-z0-9]/gi, '')
          .substring(0, 30);

        const filename = `${tag}_${safeText || 'field'}.png`;
        const actualPath = path.join(config.fieldSSDir, filename);
        await handle.screenshot({ path: actualPath });

        fieldScreenshotCount++;
      }
    } catch {
      console.warn(`⚠️ Skipping screenshot for: ${relativeXPath}`);
    }
  }

  // === 3. WRITE EXCEL ===
  const workbook = XLSX.utils.book_new();
  const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);
  XLSX.utils.book_append_sheet(workbook, worksheet, 'BASELINE');
  XLSX.writeFile(workbook, path.join(config.excelDir, 'BaselineData.xlsx'));

  console.log(`✅ Page screenshot saved.`);
  console.log(`✅ Captured ${fieldScreenshotCount} field screenshots.`);
  console.log(`✅ Excel file created at: ${path.join(config.excelDir, 'BaselineData.xlsx')}`);
});
